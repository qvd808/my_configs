require("qvd808")

-- vim.opt.shiftwidth = 4
-- vim.opt.number = true
-- vim.relativenumber = true
-- vim.opt.clipboard = "unnamedplus"
--
-- -- vim.keymap.set("n", "<space><space>x", "<cmd>source %<CR>")
-- vim.keymap.set("n", "<space>x", ":.lua<CR>")
-- vim.keymap.set("v", "<space>x", ":lua<CR>")
--
--
--
-- vim.api.nvim_create_autocmd("TextYankPost", {
--   group = vim.api.nvim_create_augroup("kickstart-highlight-yank", { clear = true }),
--   callback = function()
--     vim.highlight.on_yank()
--   end,
-- })
